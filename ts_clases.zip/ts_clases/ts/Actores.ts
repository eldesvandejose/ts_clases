class Actor
{
    /* Declaramos las propiedades */
    nombre: string;
    f_nacimiento: string;
    private static datos:string; // propiedad de clase y privada.

    constructor (nombre:string, f_nacimiento?:string)
    {
        this.nombre = nombre;
        if (f_nacimiento !== undefined)
        {
            this.f_nacimiento = f_nacimiento;
        } else {
            this.f_nacimiento = "Sin determinar";
        }
    }

    mostrar()
    {
        Actor.datos = `
            <div>
                El actor <strong>${this.nombre}</strong> nació el <cite>${this.f_nacimiento}</cite>.
            </div>
        `;
    }
}

let actor = new Actor("John Travolta", "18-02-1954");
actor.mostrar();
